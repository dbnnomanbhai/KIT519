﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentProductSupportSystem
{
    public class SupportTicket
    {
        private int ticketID;
        private string issue;
        private string status;
        private DateTime createdDate;

        public int TicketID => ticketID;
        public string Issue => issue;
        public string Status => status;
        public DateTime CreatedDate => createdDate;

        public SupportTicket(int id, string issue, string status, DateTime createdDate)
        {
            this.ticketID = id;
            this.issue = issue;
            this.status = status;
            this.createdDate = createdDate;
        }

        public static List<SupportTicket> GetTestTickets()
        {
            return new List<SupportTicket>
            {
                new SupportTicket(1, "Unable to log in", "Resolved", DateTime.Now.AddDays(1)),
                new SupportTicket(2, "System crash on task submission", "In Progress", DateTime.Now.AddDays(2)),
                new SupportTicket(3, "Bug in calendar sync", "Open", DateTime.Now.AddDays(3)),
                new SupportTicket(4, "Notifications not working", "Resolved", DateTime.Now.AddDays(4)),
                new SupportTicket(5, "UI misalignment", "In Progress", DateTime.Now.AddDays(5))
            };
        }

        public override string ToString()
        {
            return $"TicketID: {TicketID}, Issue: {Issue}, Status: {Status}, CreatedDate: {CreatedDate.ToShortDateString()}";
        }
    }
}
