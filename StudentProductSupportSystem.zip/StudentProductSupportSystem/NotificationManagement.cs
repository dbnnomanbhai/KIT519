﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentProductSupportSystem
{
    public class Notification
    {
        private int notificationID;
        private string message;
        private DateTime notificationDate;

        public int NotificationID => notificationID;
        public string Message => message;
        public DateTime NotificationDate => notificationDate;

        public Notification(int id, string message, DateTime notificationDate)
        {
            this.notificationID = id;
            this.message = message;
            this.notificationDate = notificationDate;
        }

        public static List<Notification> GetTestNotifications()
        {
            return new List<Notification>
            {
                new Notification(1, "Task deadline approaching!", DateTime.Now.AddDays(1)),
                new Notification(2, "Reminder: Meeting with Bob tomorrow.", DateTime.Now.AddDays(2)),
                new Notification(3, "Don't forget to submit your assignment.", DateTime.Now.AddDays(3)),
                new Notification(4, "New task assigned.", DateTime.Now.AddDays(4)),
                new Notification(5, "You have an event tomorrow.", DateTime.Now.AddDays(5))
            };
        }

        public override string ToString()
        {
            return $"NotificationID: {NotificationID}, Message: {Message}, NotificationDate: {NotificationDate.ToShortDateString()}";
        }
    }
}
