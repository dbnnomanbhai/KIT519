﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentProductSupportSystem
{
    public class Collaboration
    {
        private int collaborationID;
        private string taskName;
        private string assignedTo;
        private string status;

        public int CollaborationID => collaborationID;
        public string TaskName => taskName;
        public string AssignedTo => assignedTo;
        public string Status => status;

        public Collaboration(int id, string taskName, string assignedTo, string status)
        {
            this.collaborationID = id;
            this.taskName = taskName;
            this.assignedTo = assignedTo;
            this.status = status;
        }

        public static List<Collaboration> GetTestCollaborations()
        {
            return new List<Collaboration>
            {
                new Collaboration(1, "Develop Feature X", "Alice", "In Progress"),
                new Collaboration(2, "Write Documentation", "Bob", "Completed"),
                new Collaboration(3, "Review Code", "Charlie", "Pending"),
                new Collaboration(4, "Test Feature Y", "Dave", "In Progress"),
                new Collaboration(5, "UI Design", "Eve", "Completed")
            };
        }

        public override string ToString()
        {
            return $"CollaborationID: {CollaborationID}, TaskName: {TaskName}, AssignedTo: {AssignedTo}, Status: {Status}";
        }
    }
}
