﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentProductSupportSystem
{
    public class Calendar
    {
        private int calendarID;
        private string calendarName;
        private DateTime eventDate;
        private string eventDescription;

        public int CalendarID => calendarID;
        public string CalendarName => calendarName;
        public DateTime EventDate => eventDate;
        public string EventDescription => eventDescription;

        public Calendar(int id, string name, DateTime eventDate, string eventDescription)
        {
            this.calendarID = id;
            this.calendarName = name;
            this.eventDate = eventDate;
            this.eventDescription = eventDescription;
        }

        public static List<Calendar> GetTestCalendars()
        {
            return new List<Calendar>
            {
                new Calendar(1, "Work Calendar", DateTime.Now.AddDays(1), "Team Meeting"),
                new Calendar(2, "Personal Calendar", DateTime.Now.AddDays(2), "Doctor's Appointment"),
                new Calendar(3, "Study Calendar", DateTime.Now.AddDays(3), "Study Session for CS101"),
                new Calendar(4, "Work Calendar", DateTime.Now.AddDays(4), "Project Deadline"),
                new Calendar(5, "Personal Calendar", DateTime.Now.AddDays(5), "Family Gathering")
            };
        }

        public override string ToString()
        {
            return $"CalendarID: {CalendarID}, CalendarName: {CalendarName}, EventDate: {EventDate.ToShortDateString()}, EventDescription: {EventDescription}";
        }
    }
}
