﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentProductSupportSystem
{
    public class Report
    {
        private int reportID;
        private string reportName;
        private DateTime generatedDate;

        public int ReportID => reportID;
        public string ReportName => reportName;
        public DateTime GeneratedDate => generatedDate;

        public Report(int id, string reportName, DateTime generatedDate)
        {
            this.reportID = id;
            this.reportName = reportName;
            this.generatedDate = generatedDate;
        }

        public static List<Report> GetTestReports()
        {
            return new List<Report>
            {
                new Report(1, "Task Status Report", DateTime.Now.AddDays(1)),
                new Report(2, "Event Attendance Report", DateTime.Now.AddDays(2)),
                new Report(3, "User Activity Report", DateTime.Now.AddDays(3)),
                new Report(4, "Project Progress Report", DateTime.Now.AddDays(4)),
                new Report(5, "Bug Report", DateTime.Now.AddDays(5))
            };
        }

        public override string ToString()
        {
            return $"ReportID: {ReportID}, ReportName: {ReportName}, GeneratedDate: {GeneratedDate.ToShortDateString()}";
        }
    }
}
