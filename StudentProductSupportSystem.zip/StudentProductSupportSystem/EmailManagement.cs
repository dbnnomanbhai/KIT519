﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentProductSupportSystem
{
    public class Email
    {
        private int emailID;
        private string recipient;
        private string subject;
        private string body;
        private DateTime sentDate;

        public int EmailID => emailID;
        public string Recipient => recipient;
        public string Subject => subject;
        public string Body => body;
        public DateTime SentDate => sentDate;

        public Email(int id, string recipient, string subject, string body, DateTime sentDate)
        {
            this.emailID = id;
            this.recipient = recipient;
            this.subject = subject;
            this.body = body;
            this.sentDate = sentDate;
        }

        public static List<Email> GetTestEmails()
        {
            return new List<Email>
            {
                new Email(1, "alice@example.com", "Task Assigned", "You have been assigned a new task.", DateTime.Now.AddDays(1)),
                new Email(2, "bob@example.com", "Meeting Reminder", "Your meeting is tomorrow at 10 AM.", DateTime.Now.AddDays(2)),
                new Email(3, "charlie@example.com", "Task Update", "Your task status has been updated.", DateTime.Now.AddDays(3)),
                new Email(4, "dave@example.com", "Deadline Reminder", "The project deadline is approaching.", DateTime.Now.AddDays(4)),
                new Email(5, "eve@example.com", "New Event", "You have a new event tomorrow.", DateTime.Now.AddDays(5))
            };
        }

        public override string ToString()
        {
            return $"EmailID: {EmailID}, Recipient: {Recipient}, Subject: {Subject}, SentDate: {SentDate.ToShortDateString()}";
        }
    }
}
