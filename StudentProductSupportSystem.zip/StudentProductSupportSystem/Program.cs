﻿using StudentProductSupportSystem;
using System;
using System.Collections.Generic;

namespace StudentProductSupportSystemProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Welcome To The Student Support System");
            while (true)
            {
                Console.WriteLine("Select an option:");
                Console.WriteLine("1. Display Users");
                Console.WriteLine("2. Display Tasks");
                Console.WriteLine("3. Display Calendars");
                Console.WriteLine("4. Display Notifications");
                Console.WriteLine("5. Display Collaborations");
                Console.WriteLine("6. Display Emails");
                Console.WriteLine("7. Display Reports");
                Console.WriteLine("8. Display Support Tickets");
                Console.WriteLine("9. Display Enhancements");
                Console.WriteLine("0. Exit");

                Console.WriteLine("Choose option 0-9");
                var option = Console.ReadLine();

                switch (option)
                {
                    case "1":
                        DisplayData(User.GetTestUsers());
                        break;
                    case "2":
                        DisplayData(Task.GetTestTasks());
                        break;
                    case "3":
                        DisplayData(Calendar.GetTestCalendars());
                        break;
                    case "4":
                        DisplayData(Notification.GetTestNotifications());
                        break;
                    case "5":
                        DisplayData(Collaboration.GetTestCollaborations());
                        break;
                    case "6":
                        DisplayData(Email.GetTestEmails());
                        break;
                    case "7":
                        DisplayData(Report.GetTestReports());
                        break;
                    case "8":
                        DisplayData(SupportTicket.GetTestTickets());
                        break;
                    case "9":
                        DisplayData(Enhancement.GetTestEnhancements());
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }

        static void DisplayData<T>(List<T> data)
        {
            foreach (var item in data)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}
