﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentProductSupportSystem
{
    public class Enhancement
    {
        private int enhancementID;
        private string description;
        private string status;

        public int EnhancementID => enhancementID;
        public string Description => description;
        public string Status => status;

        public Enhancement(int id, string description, string status)
        {
            this.enhancementID = id;
            this.description = description;
            this.status = status;
        }

        public static List<Enhancement> GetTestEnhancements()
        {
            return new List<Enhancement>
            {
                new Enhancement(1, "Add Dark Mode", "Pending"),
                new Enhancement(2, "Improve Task Assignment", "Completed"),
                new Enhancement(3, "Add Notification Snooze", "In Progress"),
                new Enhancement(4, "Improve UI/UX", "Completed"),
                new Enhancement(5, "Add Calendar Sync with Outlook", "Pending")
            };
        }

        public override string ToString()
        {
            return $"EnhancementID: {EnhancementID}, Description: {Description}, Status: {Status}";
        }
    }
}
