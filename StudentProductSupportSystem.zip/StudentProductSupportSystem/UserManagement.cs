﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentProductSupportSystem
{
    public class User
    {
        private int userID;
        private string name;
        private string email;
        private string role;

        public int UserID => userID;
        public string Name => name;
        public string Email => email;
        public string Role => role;

        public User(int id, string name, string email, string role)
        {
            this.userID = id;
            this.name = name;
            this.email = email;
            this.role = role;
        }

        public static List<User> GetTestUsers()
        {
            return new List<User>
            {
                new User(1, "Alice", "alice@example.com", "student"),
                new User(2, "Bob", "bob@example.com", "faculty"),
                new User(3, "Charlie", "charlie@example.com", "staff"),
                new User(4, "Dave", "dave@example.com", "student"),
                new User(5, "Eve", "eve@example.com", "faculty")
            };
        }

        public override string ToString()
        {
            return $"UserID: {UserID}, Name: {Name}, Email: {Email}, Role: {Role}";
        }
    }
}
