﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentProductSupportSystem
{
    public class Task
    {
        private int taskID;
        private string taskName;
        private string description;
        private DateTime dueDate;

        public int TaskID => taskID;
        public string TaskName => taskName;
        public string Description => description;
        public DateTime DueDate => dueDate;

        public Task(int id, string taskName, string description, DateTime dueDate)
        {
            this.taskID = id;
            this.taskName = taskName;
            this.description = description;
            this.dueDate = dueDate;
        }

        public static List<Task> GetTestTasks()
        {
            return new List<Task>
            {
                new Task(1, "Complete Assignment", "Finish the assignment for CS101", DateTime.Now.AddDays(2)),
                new Task(2, "Research Paper", "Write a research paper on AI", DateTime.Now.AddDays(5)),
                new Task(3, "Meeting with Bob", "Discuss project progress with Bob", DateTime.Now.AddDays(1)),
                new Task(4, "Update Resume", "Update personal resume", DateTime.Now.AddDays(4)),
                new Task(5, "Prepare Presentation", "Prepare the final presentation for class", DateTime.Now.AddDays(3))
            };
        }

        public override string ToString()
        {
            return $"TaskID: {TaskID}, TaskName: {TaskName}, Description: {Description}, DueDate: {DueDate.ToShortDateString()}";
        }
    }
}
