﻿using System;
using System.Collections.Generic;
using static StudentProductSupportSystemProject.UserManagement;

namespace StudentProductSupportSystemProject
{
    internal class TaskManagement
    {
        public class Task
        {
            private int taskID;
            private string taskName;
            private string description;
            private DateTime dueDate;
            private string priority;
            private string status;
            private List<User> assignedUsers;

            public int TaskID => taskID;
            public string TaskName => taskName;
            public string Description => description;
            public DateTime DueDate => dueDate;
            public string Priority => priority;
            public string Status => status;
            public IReadOnlyList<User> AssignedUsers => assignedUsers.AsReadOnly();

            public Task(int id, string name, string description, DateTime dueDate, string priority)
            {
                this.taskID = id;
                this.taskName = name;
                this.description = description;
                this.dueDate = dueDate;
                this.priority = priority;
                this.status = "Pending";
                this.assignedUsers = new List<User>();
            }

            public void UpdateStatus(string newStatus)
            {
                status = newStatus;
            }

            public void AssignUser(User user)
            {
                assignedUsers.Add(user);
            }
        }

        // This method can be called later for testing Task Management functionality
        public static void TestTaskManagement()
        {
            // Create users to assign to tasks
            User user1 = new User(1, "Alice", "alice@example.com", "password123", "student");
            User user2 = new User(2, "Bob", "bob@example.com", "password123", "faculty");
            User user3 = new User(3, "Charlie", "charlie@example.com", "password123", "staff");

            // Create tasks with detailed data
            List<Task> tasks = new List<Task>
            {
                new Task(1, "Math Homework", "Complete exercises from chapter 4", DateTime.Now.AddDays(2), "High"),
                new Task(2, "Project Report", "Prepare the final project report", DateTime.Now.AddDays(5), "Medium"),
                new Task(3, "Science Experiment", "Gather materials for the science experiment", DateTime.Now.AddDays(3), "Low"),
                new Task(4, "Presentation Preparation", "Design slides for the upcoming presentation", DateTime.Now.AddDays(1), "High"),
                new Task(5, "Budget Review", "Review budget proposal for next quarter", DateTime.Now.AddDays(7), "Medium")
            };

            // Assign users to tasks
            tasks[0].AssignUser(user1);
            tasks[0].AssignUser(user2);
            tasks[1].AssignUser(user3);
            tasks[2].AssignUser(user1);
            tasks[3].AssignUser(user2);
            tasks[4].AssignUser(user1);
            tasks[4].AssignUser(user3);

            // Display task details
            Console.WriteLine("Tasks:");
            foreach (var task in tasks)
            {
                Console.WriteLine($"\nTask ID: {task.TaskID}, Name: {task.TaskName}, Due Date: {task.DueDate.ToShortDateString()}, Priority: {task.Priority}, Status: {task.Status}");
                Console.WriteLine("Assigned Users:");
                foreach (var user in task.AssignedUsers)
                {
                    Console.WriteLine($"- {user.Name} ({user.Role})");
                }
            }

            // Update status of a task for demonstration
            tasks[0].UpdateStatus("Completed");
            Console.WriteLine($"\nUpdated Status for Task ID {tasks[0].TaskID}: {tasks[0].Status}");
        }
    }
}
