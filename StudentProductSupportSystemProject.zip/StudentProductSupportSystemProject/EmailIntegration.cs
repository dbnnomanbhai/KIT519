﻿using System;
using System.Collections.Generic;

namespace StudentProductSupportSystemProject
{
    internal class EmailIntegration
    {
        public class Email
        {
            private int emailID;
            private string sender;
            private string subject;
            private string body;

            public int EmailID => emailID;
            public string Sender => sender;
            public string Subject => subject;
            public string Body => body;

            public Email(int id, string sender, string subject, string body)
            {
                this.emailID = id;
                this.sender = sender;
                this.subject = subject;
                this.body = body;
            }

            // Converts an email into a task
            public Task ConvertToTask()
            {
                return new Task(emailID, subject, body, DateTime.Now.AddDays(1), "Medium");
            }
        }

        public class Task
        {
            private int taskID;
            private string title;
            private string description;
            private DateTime dueDate;
            private string priority;

            public int TaskID => taskID;
            public string Title => title;
            public string Description => description;
            public DateTime DueDate => dueDate;
            public string Priority => priority;

            public Task(int id, string title, string description, DateTime dueDate, string priority)
            {
                this.taskID = id;
                this.title = title;
                this.description = description;
                this.dueDate = dueDate;
                this.priority = priority;
            }
        }

        // This method can be called later for testing the Email and Task conversion
        public static void TestEmailIntegration()
        {
            // Create sample emails
            List<Email> emails = new List<Email>
            {
                new Email(1, "professor@example.com", "Assignment Reminder", "Complete your assignment by next week."),
                new Email(2, "teammate@example.com", "Group Project Update", "Let's meet to discuss the next steps."),
                new Email(3, "admin@example.com", "System Maintenance", "Scheduled maintenance will occur this Saturday."),
                new Email(4, "advisor@example.com", "Meeting Reminder", "Don't forget our advisory meeting tomorrow."),
                new Email(5, "hr@example.com", "Policy Update", "Please review the latest updates to our policies.")
            };

            // Display the emails
            Console.WriteLine("Emails:");
            foreach (var email in emails)
            {
                Console.WriteLine($"ID: {email.EmailID}, Sender: {email.Sender}, Subject: {email.Subject}");
            }

            // Convert an email to a task and display it
            Task task = emails[0].ConvertToTask();
            Console.WriteLine("\nConverted Email to Task:");
            Console.WriteLine($"Task ID: {task.TaskID}, Title: {task.Title}, Due Date: {task.DueDate}, Priority: {task.Priority}");
        }
    }
}
