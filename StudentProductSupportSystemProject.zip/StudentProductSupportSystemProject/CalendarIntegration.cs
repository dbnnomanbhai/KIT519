﻿using System;
using System.Collections.Generic;
using static StudentProductSupportSystemProject.UserManagement;

namespace StudentProductSupportSystemProject
{
    internal class CalendarIntegration
    {
        public class Event
        {
            private int eventID;
            private string eventName;
            private DateTime date;
            private User createdBy;

            public int EventID => eventID;
            public string EventName => eventName;
            public DateTime Date => date;
            public User CreatedBy => createdBy;

            public Event(int id, string name, DateTime date, User creator)
            {
                this.eventID = id;
                this.eventName = name;
                this.date = date;
                this.createdBy = creator;
            }
        }

        public class Calendar
        {
            private int calendarID;
            private User owner;
            private List<Event> events;

            public int CalendarID => calendarID;
            public User Owner => owner;
            public IReadOnlyList<Event> Events => events.AsReadOnly();

            public Calendar(int id, User owner)
            {
                this.calendarID = id;
                this.owner = owner;
                this.events = new List<Event>();
            }

            public void AddEvent(Event newEvent)
            {
                events.Add(newEvent);
            }

            public void RemoveEvent(int eventID)
            {
                events.RemoveAll(e => e.EventID == eventID);
            }
        }

        // This method can be used for testing or initializing the calendar later
        public static void TestCalendar()
        {
            // Create a user
            User owner = new User(1, "Alice", "alice@example.com", "password123", "student");

            // Create a calendar for the user
            Calendar calendar = new Calendar(1, owner);

            // Add multiple events to the calendar
            calendar.AddEvent(new Event(1, "Math Exam", DateTime.Now.AddDays(7), owner));
            calendar.AddEvent(new Event(2, "Group Study", DateTime.Now.AddDays(3), owner));
            calendar.AddEvent(new Event(3, "Science Fair", DateTime.Now.AddDays(14), owner));
            calendar.AddEvent(new Event(4, "Literature Festival", DateTime.Now.AddDays(10), owner));
            calendar.AddEvent(new Event(5, "Project Submission", DateTime.Now.AddDays(5), owner));

            // Display the calendar events
            Console.WriteLine($"Calendar for {owner.Name}:");
            foreach (var evt in calendar.Events)
            {
                Console.WriteLine($"Event ID: {evt.EventID}, Name: {evt.EventName}, Date: {evt.Date.ToShortDateString()}, Created By: {evt.CreatedBy.Name}");
            }
        }
    }
}
