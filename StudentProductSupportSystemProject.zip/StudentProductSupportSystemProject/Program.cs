﻿using System;
using System.Collections.Generic;
using static StudentProductSupportSystemProject.UserManagement;
using static StudentProductSupportSystemProject.NotificationsReminder;
using static StudentProductSupportSystemProject.Reporting;
using static StudentProductSupportSystemProject.EmailIntegration;  // Added Email Integration
using Task = StudentProductSupportSystemProject.TaskManagement.Task;  // Alias for Task in TaskManagement

namespace StudentProductSupportSystemProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Sample Users for Testing
            List<User> users = new List<User>
            {
                new User(1, "Alice", "alice@example.com", "password123", "student"),
                new User(2, "Bob", "bob@example.com", "password123", "faculty"),
                new User(3, "Charlie", "charlie@example.com", "password123", "staff")
            };

            // Sample Tasks for Testing (Use Task from TaskManagement)
            List<Task> tasks = new List<Task>
            {
                new Task(1, "Math Homework", "Complete exercises from chapter 4", DateTime.Now.AddDays(2), "High"),
                new Task(2, "Project Report", "Prepare the final project report", DateTime.Now.AddDays(5), "Medium")
            };

            // Sample Groups for Collaboration (assuming the `Group` class is used for collaboration)
            var groups = Collaboration.Group.GetSampleGroups();

            // Main menu
            bool running = true;
            while (running)
            {
                Console.Clear();
                Console.WriteLine("Select a feature to test:");
                Console.WriteLine("1. User Management");
                Console.WriteLine("2. Task Management");
                Console.WriteLine("3. Notifications Reminder");
                Console.WriteLine("4. Reporting");
                Console.WriteLine("5. Email Integration");  // Added option for Email Integration
                Console.WriteLine("6. Collaboration");  // Added option for Collaboration
                Console.WriteLine("7. Exit");
                Console.Write("Enter your choice: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        // User Management
                        Console.WriteLine("\nUser Management:");
                        // Call the TestUserManagement method to display user details
                        TestUserManagement();
                        Console.WriteLine("\nPress any key to go back to the menu.");
                        Console.ReadKey();
                        break;

                    case "2":
                        // Task Management
                        Console.WriteLine("\nTask Management:");
                        foreach (var task in tasks)
                        {
                            Console.WriteLine($"Task ID: {task.TaskID}, Task Name: {task.TaskName}, Due Date: {task.DueDate.ToShortDateString()}, Priority: {task.Priority}");
                        }
                        Console.WriteLine("\nPress any key to go back to the menu.");
                        Console.ReadKey();
                        break;

                    case "3":
                        // Notifications Reminder
                        var notifications = Notification.GetSampleNotifications(users);
                        Console.WriteLine("\nNotifications Reminder:");
                        foreach (var notification in notifications)
                        {
                            Console.WriteLine($"Notification ID: {notification.NotificationID}, Message: {notification.Message}, Sent by: {notification.Sender.Name} to {notification.Receiver.Name}");
                        }
                        Console.WriteLine("\nPress any key to go back to the menu.");
                        Console.ReadKey();
                        break;

                    case "4":
                        // Reporting
                        var report = Report.GetSampleReport(tasks);
                        Console.WriteLine("\nReporting:");
                        Console.WriteLine($"Report ID: {report.ReportID}, Completion Rate: {report.CompletionRate}%, Efficiency Rate: {report.EfficiencyRate}%");
                        Console.WriteLine("\nPress any key to go back to the menu.");
                        Console.ReadKey();
                        break;

                    case "5":
                        // Email Integration
                        Console.WriteLine("\nEmail Integration:");
                        TestEmailIntegration();  // Test the email integration functionality
                        Console.WriteLine("\nPress any key to go back to the menu.");
                        Console.ReadKey();
                        break;

                    case "6":
                        // Collaboration
                        Console.WriteLine("\nCollaboration:");
                        foreach (var group in groups)
                        {
                            Console.WriteLine($"Group: {group.GroupName}, Group ID: {group.GroupID}");
                            Console.WriteLine("Members:");
                            foreach (var member in group.Members)
                            {
                                Console.WriteLine($"- {member.Name} ({member.Role})");
                            }
                            Console.WriteLine("Group Tasks:");
                            foreach (var task in group.GroupTasks)
                            {
                                Console.WriteLine($"- {task.TaskName} (Due: {task.DueDate.ToShortDateString()}, Priority: {task.Priority})");
                            }
                        }
                        Console.WriteLine("\nPress any key to go back to the menu.");
                        Console.ReadKey();
                        break;

                    case "7":
                        // Exit
                        running = false;
                        break;

                    default:
                        Console.WriteLine("\nInvalid choice, please select a valid option.");
                        Console.WriteLine("\nPress any key to go back to the menu.");
                        Console.ReadKey();
                        break;
                }
            }

            Console.WriteLine("Thank you for using the Student Product Support System!");
        }
    }
}
