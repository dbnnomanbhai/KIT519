﻿using System;
using System.Collections.Generic;
using System.Linq;
using static StudentProductSupportSystemProject.TaskManagement;

namespace StudentProductSupportSystemProject
{
    internal class Reporting
    {
        public class Report
        {
            private int reportID;
            private float completionRate;
            private float efficiencyRate;
            private DateTime generatedDate;

            public int ReportID => reportID;
            public float CompletionRate => completionRate;
            public float EfficiencyRate => efficiencyRate;
            public DateTime GeneratedDate => generatedDate;

            public Report(int id)
            {
                this.reportID = id;
                this.generatedDate = DateTime.Now;
            }

            public void GenerateReport(List<Task> tasks)
            {
                int completedTasks = tasks.Count(t => t.Status == "completed");
                completionRate = (float)completedTasks / tasks.Count * 100;
                efficiencyRate = new Random().Next(70, 100); // Random efficiency rate between 70 and 100
            }

            // Sample report generation for testing
            public static Report GetSampleReport(List<Task> tasks)
            {
                Report report = new Report(1);
                report.GenerateReport(tasks);
                return report;
            }
        }
    }
}
