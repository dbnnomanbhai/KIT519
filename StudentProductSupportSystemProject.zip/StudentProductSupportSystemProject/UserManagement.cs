﻿using System;
using System.Collections.Generic;

namespace StudentProductSupportSystemProject
{
    internal class UserManagement
    {
        public class User
        {
            private int userID;
            private string name;
            private string email;
            private string password;
            private string role;

            public int UserID => userID;
            public string Name => name;
            public string Email => email;
            public string Role => role;

            public User(int id, string name, string email, string password, string role)
            {
                this.userID = id;
                this.name = name;
                this.email = email;
                this.password = password;
                this.role = role;
            }

            // Updates the user's profile
            public void UpdateProfile(string newName, string newEmail)
            {
                name = newName;
                email = newEmail;
            }
        }

        // This method can be called later for testing User Management functionality
        public static void TestUserManagement()
        {
            // Create some users
            List<User> users = new List<User>
            {
                new User(1, "Alice", "alice@example.com", "password123", "student"),
                new User(2, "Bob", "bob@example.com", "password123", "faculty"),
                new User(3, "Charlie", "charlie@example.com", "password123", "staff")
            };

            // Display the created users
            Console.WriteLine("Created Users:");
            foreach (var user in users)
            {
                Console.WriteLine($"ID: {user.UserID}, Name: {user.Name}, Email: {user.Email}, Role: {user.Role}");
            }
        }
    }
}
