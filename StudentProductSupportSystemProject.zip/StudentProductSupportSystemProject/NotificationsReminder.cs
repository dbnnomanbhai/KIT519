﻿using System;
using System.Collections.Generic;
using static StudentProductSupportSystemProject.UserManagement;

namespace StudentProductSupportSystemProject
{
    internal class NotificationsReminder
    {
        public class Notification
        {
            private int notificationID;
            private string message;
            private DateTime date;
            private User sender;
            private User receiver;

            public int NotificationID => notificationID;
            public string Message => message;
            public DateTime Date => date;
            public User Sender => sender;
            public User Receiver => receiver;

            public Notification(int id, string message, DateTime date, User sender, User receiver)
            {
                this.notificationID = id;
                this.message = message;
                this.date = date;
                this.sender = sender;
                this.receiver = receiver;
            }

            // Sample notifications for testing purposes
            public static List<Notification> GetSampleNotifications(List<User> users)
            {
                return new List<Notification>
                {
                    new Notification(1, "Task due soon!", DateTime.Now, users[0], users[1]),
                    new Notification(2, "Meeting reminder", DateTime.Now.AddHours(1), users[1], users[2]),
                    new Notification(3, "New assignment posted", DateTime.Now.AddDays(1), users[2], users[0]),
                    new Notification(4, "Project update", DateTime.Now.AddDays(2), users[0], users[1]),
                    new Notification(5, "Deadline approaching", DateTime.Now.AddDays(3), users[1], users[2])
                };
            }
        }
    }
}
