﻿using System;
using System.Collections.Generic;
using static StudentProductSupportSystemProject.UserManagement;
using static StudentProductSupportSystemProject.TaskManagement;

namespace StudentProductSupportSystemProject
{
    internal class Collaboration
    {
        public class Group
        {
            private int groupID;
            private string groupName;
            private List<User> members;
            private List<Task> groupTasks;

            public int GroupID => groupID;
            public string GroupName => groupName;
            public IReadOnlyList<User> Members => members.AsReadOnly();
            public IReadOnlyList<Task> GroupTasks => groupTasks.AsReadOnly();

            public Group(int id, string name)
            {
                this.groupID = id;
                this.groupName = name;
                this.members = new List<User>();
                this.groupTasks = new List<Task>();
            }

            public void AddMember(User user)
            {
                if (!members.Contains(user))
                    members.Add(user);
            }

            public void AddTask(Task task)
            {
                groupTasks.Add(task);
            }

            // Use predefined users inside the method for sample groups
            public static List<Group> GetSampleGroups()
            {
                var users = new List<User>
                {
                    new User(1, "Alice", "alice@example.com", "password123", "student"),
                    new User(2, "Bob", "bob@example.com", "password123", "faculty"),
                    new User(3, "Charlie", "charlie@example.com", "password123", "staff")
                };

                Group studyGroup = new Group(1, "Study Group");
                studyGroup.AddMember(users[0]); // Alice
                studyGroup.AddMember(users[1]); // Bob

                Group projectGroup = new Group(2, "Project Group");
                projectGroup.AddMember(users[1]); // Bob
                projectGroup.AddMember(users[2]); // Charlie

                return new List<Group> { studyGroup, projectGroup };
            }
        }
    }
}
